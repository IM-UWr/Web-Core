---
nazwa: "Topologia"
nazwa_en: "Topology"
prowadzacy:
  - "Paweł Krupski"
  - "Grzegorz Plebanek"
  - "Piotr Borodulin-Nadzieja"
  - "Szymon Żeberski"
  - "Robert Rałowski"
kontakt: "Piotr.Borodulin-Nadzieja@math.uni.wroc.pl"
archiwum: "http://www.math.uni.wroc.pl/~pborod/seminarium/"
zaklad: "teoria-mnogosci-i-topologia"
aktywne: true
tresc_en: "Seminar of the Department of Set Theory and Topology."
haslo: "Topologia ogólna i teoria mnogości"
haslo_en: "General topology and set theory"
opublikowany: true
---

Seminarium Zakładu Teorii Mnogości i Topologii.
